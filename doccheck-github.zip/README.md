# 文稿检查系统

面向项目交付文档的本地检查工具，支持 DOC/DOCX/PDF 导入、合同基准确认、页码/格式/标点/合同一致性/依据/阶段逻辑/身份表述检查、上下文概率评分、批量判定、自动修复和报告导出。

## 环境要求

- Python 3.10+
- macOS：`.doc` 转换和系统 OCR 依赖系统自带的 `textutil`、Vision；这些能力不可用时，仍可检查 DOCX 和文字型 PDF。
- 可选：WPS 或 LibreOffice，用于更高保真度的 Word/PDF 转换。

## 安装与启动

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
./run.sh
```

启动后打开：<http://127.0.0.1:8600>

也可以直接运行：

```bash
python -m doccheck.webapp.app
```

## JEV/TypeSafe 概率评分

默认使用本地上下文启发式评分。配置 JEV 后，系统会将候选问题批量发送给兼容接口，并结合长期合同基准与当前段落上下文进行合并评分。

不要把真实密钥写入 `config.yaml`、代码或 Git。启动前通过环境变量配置：

```bash
export TYPESAFE_API_KEY="你的密钥"
export JEV_BASE_URL="https://api.typesafe.ai/v1"
export JEV_MODEL="jev-latest"
export JEV_ENABLED="true"
./run.sh
```

变量示例见 `.env.example`。当前适配器默认使用 TypeSafe Jev 的 `systemone` 兼容端点。

## 配置和运行数据

- `config.yaml`：合同基准、时间线、规则白名单和 JEV 默认配置。首次使用前请在页面1确认合同信息。
- `workdir/`：上传文件、会话、上下文截图和导出报告，首次运行时自动创建。
- `backups/`：自动修复前的备份，首次修复时自动创建。

不要把真实合同、上传文档、修复备份、运行日志、API 密钥或 `graphify-out/` 提交到公开仓库。

## 测试

```bash
python tests/test_typesafe_adapter.py
python tests/test_probability_heuristic.py
```

仓库中只保留不依赖本机文档目录的回归测试。真实文档验证需要另外准备 DOC/DOCX/PDF 样例，不随代码包发布。

## 目录结构

```text
doccheck/
  rules/              检查规则
  webapp/             Flask 页面、模板和静态资源
  docloader.py        DOCX/PDF 统一加载
  probability.py      上下文与 JEV 概率评分
  engine.py           检查调度
  repair.py           DOCX 自动修复与回滚
run.sh                启动脚本
config.yaml           默认配置模板
requirements.txt      Python 依赖
tests/                可移植回归测试
```

